<?php
if (!defined('TTH_SYSTEM')) { die('Please stop!'); }
//
?>
<!-- Menu path -->
<div class="row">
	<ol class="breadcrumb">
		<li>
			<a href="<?php echo ADMIN_DIR?>"><i class="fa fa-home"></i> Trang chủ</a>
		</li>
		<li>
			<i class="fa fa-sitemap"></i> Thông tin hệ thống
		</li>
		<li>
			<i class="fa fa-book"></i> Thống kê hoạt động
		</li>
	</ol>
</div>
<!-- /.row -->
<?php
dashboardCoreAdmin();
//----------------------------
?>

<div class="row">
	<div class="col-lg-12">
		<div class="panel panel-default panel-no-border">
			<div class="table-responsive">
				(-no-)
			</div>
		</div>
	</div>
</div>