<?php
if (!defined('TTH_SYSTEM')) { die('Please stop!'); }
//
?>

<div class="footer-text">
	<p class="company"></p>
	<p><i class="fa fa-envelope-o fa-fw"></i> <span class="email"></span></p>
	<p><i class="fa fa-phone fa-fw"></i> <span class="phone"></span></p>
</div>